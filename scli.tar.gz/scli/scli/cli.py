"""Main CLI entry point for scli."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

from .core.config import ConfigManager
from .core.model_manager import ModelManager
from .core.conversation import ConversationManager
from .ui.interactive import InteractiveChatUI
from .ui.formatter import Formatter

app = typer.Typer(
    name="scli",
    help="Offline CLI Assistant powered by open-source language models",
    add_completion=False
)

models_app = typer.Typer(help="Manage language models")
config_app = typer.Typer(help="Manage configuration")
history_app = typer.Typer(help="Manage conversation history")

app.add_typer(models_app, name="models")
app.add_typer(config_app, name="config")
app.add_typer(history_app, name="history")

console = Console()


def get_managers(config_path: Optional[Path] = None):
    """Get initialized manager instances.

    Args:
        config_path: Optional path to config file

    Returns:
        Tuple of (config_manager, model_manager, conversation_manager)
    """
    config_manager = ConfigManager(config_path)
    model_manager = ModelManager(config_manager)
    conversation_manager = ConversationManager(config_manager.history.save_path)

    return config_manager, model_manager, conversation_manager


@app.command()
def chat(
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model to use"),
    system: Optional[str] = typer.Option(None, "--system", "-s", help="System prompt"),
    temperature: Optional[float] = typer.Option(None, "--temperature", "-t", help="Temperature"),
    config_path: Optional[Path] = typer.Option(None, "--config", "-c", help="Config file path")
):
    """Start an interactive chat session."""
    config_manager, model_manager, conversation_manager = get_managers(config_path)

    # Override temperature if specified
    if temperature is not None:
        config_manager.inference.temperature = temperature

    # Load model
    model_name = model or config_manager.default_model
    if not model_name:
        console.print("[red]Error:[/red] No model specified and no default model configured")
        console.print("[yellow]Tip:[/yellow] Use 'scli models add' to add a model first")
        raise typer.Exit(1)

    console.print(f"[cyan]Loading model:[/cyan] {model_name}")
    if not model_manager.load_model(model_name):
        console.print(f"[red]Error:[/red] Failed to load model: {model_name}")
        raise typer.Exit(1)

    # Start interactive chat
    chat_ui = InteractiveChatUI(
        model_manager=model_manager,
        config_manager=config_manager,
        conversation_manager=conversation_manager,
        system_prompt=system
    )

    try:
        chat_ui.start()
    finally:
        model_manager.unload_model()


@app.command()
def query(
    prompt: str = typer.Argument(..., help="Query to send to the model"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model to use"),
    temperature: Optional[float] = typer.Option(None, "--temperature", "-t", help="Temperature"),
    max_tokens: Optional[int] = typer.Option(None, "--max-tokens", help="Maximum tokens"),
    config_path: Optional[Path] = typer.Option(None, "--config", "-c", help="Config file path")
):
    """Send a single query to the model."""
    config_manager, model_manager, conversation_manager = get_managers(config_path)

    # Load model
    model_name = model or config_manager.default_model
    if not model_name:
        console.print("[red]Error:[/red] No model specified and no default model configured")
        raise typer.Exit(1)

    console.print(f"[cyan]Loading model:[/cyan] {model_name}")
    if not model_manager.load_model(model_name):
        console.print(f"[red]Error:[/red] Failed to load model: {model_name}")
        raise typer.Exit(1)

    try:
        # Generate response
        console.print(f"\n[bold cyan]Query:[/bold cyan] {prompt}\n")
        console.print("[dim]Generating response...[/dim]\n")

        response = model_manager.generate(
            prompt=f"User: {prompt}\n\nAssistant: ",
            temperature=temperature,
            max_tokens=max_tokens or config_manager.inference.max_tokens,
            stream=False
        )

        console.print(f"[bold green]Response:[/bold green]\n{response}\n")

    finally:
        model_manager.unload_model()


# Model management commands

@models_app.command("list")
def models_list(
    config_path: Optional[Path] = typer.Option(None, "--config", "-c", help="Config file path")
):
    """List all configured models."""
    config_manager, _, _ = get_managers(config_path)
    formatter = Formatter()

    models = config_manager.list_models()

    if not models:
        console.print("[yellow]No models configured[/yellow]")
        console.print("[cyan]Tip:[/cyan] Use 'scli models add' to add a model")
        return

    rows = []
    default_model = config_manager.default_model
    for name, config in models.items():
        is_default = "✓" if name == default_model else ""
        rows.append([
            is_default,
            name,
            config.type,
            config.path,
            f"{config.context_length}"
        ])

    formatter.print_table(
        headers=["Default", "Name", "Type", "Path", "Context"],
        rows=rows,
        title="Configured Models"
    )


@models_app.command("add")
def models_add(
    name: str = typer.Argument(..., help="Model name"),
    path: str = typer.Argument(..., help="Path to model file"),
    model_type: str = typer.Option("llama.cpp", "--type", "-t", help="Model type"),
    context_length: int = typer.Option(2048, "--context", help="Context length"),
    temperature: float = typer.Option(0.7, "--temperature", help="Default temperature"),
    set_default: bool = typer.Option(False, "--default", "-d", help="Set as default model"),
    config_path: Optional[Path] = typer.Option(None, "--config", "-c", help="Config file path")
):
    """Add a new model to configuration."""
    config_manager, _, _ = get_managers(config_path)

    # Check if model file exists
    model_path = Path(path)
    if not model_path.exists():
        console.print(f"[red]Error:[/red] Model file not found: {path}")
        raise typer.Exit(1)

    config_manager.add_model(
        name=name,
        path=str(model_path.absolute()),
        model_type=model_type,
        set_default=set_default,
        context_length=context_length,
        temperature=temperature
    )

    console.print(f"[green]✓[/green] Model '{name}' added successfully")
    if set_default:
        console.print(f"[green]✓[/green] Set as default model")


@models_app.command("remove")
def models_remove(
    name: str = typer.Argument(..., help="Model name to remove"),
    config_path: Optional[Path] = typer.Option(None, "--config", "-c", help="Config file path")
):
    """Remove a model from configuration."""
    config_manager, _, _ = get_managers(config_path)

    if name not in config_manager.list_models():
        console.print(f"[red]Error:[/red] Model '{name}' not found")
        raise typer.Exit(1)

    confirm = typer.confirm(f"Are you sure you want to remove model '{name}'?")
    if not confirm:
        console.print("[yellow]Cancelled[/yellow]")
        return

    config_manager.remove_model(name)
    console.print(f"[green]✓[/green] Model '{name}' removed")


@models_app.command("info")
def models_info(
    name: Optional[str] = typer.Argument(None, help="Model name (default model if not specified)"),
    config_path: Optional[Path] = typer.Option(None, "--config", "-c", help="Config file path")
):
    """Show information about a model."""
    config_manager, _, _ = get_managers(config_path)
    formatter = Formatter()

    model_config = config_manager.get_model_config(name)
    if not model_config:
        console.print(f"[red]Error:[/red] Model not found")
        raise typer.Exit(1)

    model_info = {
        'name': model_config.name,
        'type': model_config.type,
        'path': model_config.path,
        'context_length': model_config.context_length,
        'temperature': model_config.temperature,
        'loaded': False
    }

    formatter.print_model_info(model_info)


# Configuration commands

@config_app.command("show")
def config_show(
    config_path: Optional[Path] = typer.Option(None, "--config", "-c", help="Config file path")
):
    """Show current configuration."""
    config_manager, _, _ = get_managers(config_path)

    console.print(f"\n[bold cyan]Configuration File:[/bold cyan] {config_manager.config_path}\n")
    console.print(f"[bold]Default Model:[/bold] {config_manager.default_model or 'None'}")
    console.print(f"[bold]Max Tokens:[/bold] {config_manager.inference.max_tokens}")
    console.print(f"[bold]Stream:[/bold] {config_manager.inference.stream}")
    console.print(f"[bold]Markdown Rendering:[/bold] {config_manager.ui.markdown_rendering}")
    console.print(f"[bold]Syntax Highlighting:[/bold] {config_manager.ui.syntax_highlighting}")
    console.print(f"[bold]Auto-save History:[/bold] {config_manager.history.auto_save}\n")


@config_app.command("set-default")
def config_set_default(
    name: str = typer.Argument(..., help="Model name to set as default"),
    config_path: Optional[Path] = typer.Option(None, "--config", "-c", help="Config file path")
):
    """Set the default model."""
    config_manager, _, _ = get_managers(config_path)

    if name not in config_manager.list_models():
        console.print(f"[red]Error:[/red] Model '{name}' not found")
        raise typer.Exit(1)

    config_manager.set_default_model(name)
    console.print(f"[green]✓[/green] Default model set to '{name}'")


# History commands

@history_app.command("list")
def history_list(
    limit: int = typer.Option(10, "--limit", "-n", help="Number of conversations to show"),
    config_path: Optional[Path] = typer.Option(None, "--config", "-c", help="Config file path")
):
    """List recent conversations."""
    config_manager, _, conversation_manager = get_managers(config_path)
    formatter = Formatter()

    conversations = conversation_manager.list_conversations(limit=limit)

    if not conversations:
        console.print("[yellow]No saved conversations[/yellow]")
        return

    rows = [
        [conv['conversation_id'], conv['created_at'], conv['updated_at']]
        for conv in conversations
    ]

    formatter.print_table(
        headers=["ID", "Created", "Last Updated"],
        rows=rows,
        title=f"Recent Conversations (Last {limit})"
    )


@history_app.command("clear")
def history_clear(
    config_path: Optional[Path] = typer.Option(None, "--config", "-c", help="Config file path")
):
    """Clear all conversation history."""
    config_manager, _, conversation_manager = get_managers(config_path)

    confirm = typer.confirm("Are you sure you want to clear all conversation history?")
    if not confirm:
        console.print("[yellow]Cancelled[/yellow]")
        return

    conversation_manager.clear_all()
    console.print("[green]✓[/green] All conversation history cleared")


@app.command()
def version():
    """Show version information."""
    console.print("[bold cyan]scli[/bold cyan] version [bold]1.0.0[/bold]")
    console.print("Offline CLI Assistant powered by open-source LLMs")


def main():
    """Main entry point."""
    app()


if __name__ == "__main__":
    main()
