"""Llama.cpp plugin for GGUF model support."""

import os
from typing import Dict, Any, Optional, Iterator, Union
from pathlib import Path

try:
    from llama_cpp import Llama
    LLAMA_CPP_AVAILABLE = True
except ImportError:
    LLAMA_CPP_AVAILABLE = False

from ..base import ModelPlugin, ModelInfo


class LlamaCppPlugin(ModelPlugin):
    """Plugin for llama.cpp backend (GGUF models)."""

    def __init__(self, model_path: str, config: Dict[str, Any]):
        """Initialize llama.cpp plugin.

        Args:
            model_path: Path to GGUF model file
            config: Configuration dictionary
        """
        super().__init__(model_path, config)

        if not LLAMA_CPP_AVAILABLE:
            raise ImportError(
                "llama-cpp-python is not installed. "
                "Install it with: pip install llama-cpp-python"
            )

        self.context_length = config.get('context_length', 2048)
        self.n_threads = config.get('n_threads', os.cpu_count())
        self.n_gpu_layers = config.get('n_gpu_layers', 0)
        self.verbose = config.get('verbose', False)

    def load_model(self) -> bool:
        """Load the GGUF model.

        Returns:
            True if successful, False otherwise
        """
        try:
            if not Path(self.model_path).exists():
                print(f"Error: Model file not found: {self.model_path}")
                return False

            print(f"Loading model from {self.model_path}...")

            self.model = Llama(
                model_path=self.model_path,
                n_ctx=self.context_length,
                n_threads=self.n_threads,
                n_gpu_layers=self.n_gpu_layers,
                verbose=self.verbose
            )

            self.loaded = True
            print("Model loaded successfully!")
            return True

        except Exception as e:
            print(f"Error loading model: {e}")
            self.loaded = False
            return False

    def unload_model(self) -> bool:
        """Unload the model from memory.

        Returns:
            True if successful, False otherwise
        """
        try:
            if self.model is not None:
                del self.model
                self.model = None
            self.loaded = False
            return True
        except Exception as e:
            print(f"Error unloading model: {e}")
            return False

    def generate(
        self,
        prompt: str,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None,
        repeat_penalty: Optional[float] = None,
        stop: Optional[list] = None,
        stream: bool = False,
        **kwargs
    ) -> Union[str, Iterator[str]]:
        """Generate text using llama.cpp.

        Args:
            prompt: Input prompt
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Nucleus sampling parameter
            top_k: Top-k sampling parameter
            repeat_penalty: Repetition penalty
            stop: Stop sequences
            stream: Whether to stream the response
            **kwargs: Additional parameters

        Returns:
            Generated text or iterator of text chunks
        """
        if not self.loaded or self.model is None:
            raise RuntimeError("Model is not loaded. Call load_model() first.")

        # Use config defaults if not specified
        defaults = self.get_default_parameters()
        max_tokens = max_tokens or defaults['max_tokens']
        temperature = temperature if temperature is not None else defaults['temperature']
        top_p = top_p if top_p is not None else defaults['top_p']
        top_k = top_k if top_k is not None else defaults['top_k']
        repeat_penalty = repeat_penalty if repeat_penalty is not None else defaults['repeat_penalty']

        try:
            response = self.model(
                prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                top_k=top_k,
                repeat_penalty=repeat_penalty,
                stop=stop or [],
                stream=stream,
                **kwargs
            )

            if stream:
                return self._stream_response(response)
            else:
                return response['choices'][0]['text']

        except Exception as e:
            raise RuntimeError(f"Error generating text: {e}")

    def _stream_response(self, response) -> Iterator[str]:
        """Stream response chunks.

        Args:
            response: Streaming response from llama.cpp

        Yields:
            Text chunks
        """
        for chunk in response:
            if 'choices' in chunk and len(chunk['choices']) > 0:
                text = chunk['choices'][0].get('text', '')
                if text:
                    yield text

    def get_model_info(self) -> ModelInfo:
        """Get model metadata.

        Returns:
            ModelInfo object
        """
        return ModelInfo(
            name=Path(self.model_path).stem,
            type="llama.cpp",
            path=self.model_path,
            parameters=self.config,
            context_length=self.context_length,
            loaded=self.loaded
        )

    def validate_config(self) -> bool:
        """Validate configuration.

        Returns:
            True if valid, False otherwise
        """
        if not super().validate_config():
            return False

        # Check if model file exists
        if not Path(self.model_path).exists():
            print(f"Model file not found: {self.model_path}")
            return False

        # Check if it's a GGUF file
        if not self.model_path.endswith('.gguf'):
            print("Warning: Model file should be a GGUF file (.gguf extension)")

        return True

    def chat_format(self, messages: list) -> str:
        """Format messages for chat completion.

        Args:
            messages: List of message dictionaries with 'role' and 'content'

        Returns:
            Formatted prompt string
        """
        # Basic chat format - can be customized for specific models
        prompt = ""
        for msg in messages:
            role = msg.get('role', 'user')
            content = msg.get('content', '')

            if role == 'system':
                prompt += f"System: {content}\n\n"
            elif role == 'user':
                prompt += f"User: {content}\n\n"
            elif role == 'assistant':
                prompt += f"Assistant: {content}\n\n"

        prompt += "Assistant: "
        return prompt
