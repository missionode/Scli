"""Base plugin interface for model backends."""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Iterator, Union
from dataclasses import dataclass


@dataclass
class ModelInfo:
    """Model metadata."""
    name: str
    type: str
    path: str
    parameters: Dict[str, Any]
    context_length: int
    loaded: bool = False


class ModelPlugin(ABC):
    """Abstract base class for model plugins.

    All model backend implementations must inherit from this class
    and implement the required methods.
    """

    def __init__(self, model_path: str, config: Dict[str, Any]):
        """Initialize the plugin.

        Args:
            model_path: Path to the model file
            config: Configuration dictionary for the model
        """
        self.model_path = model_path
        self.config = config
        self.model = None
        self.loaded = False

    @abstractmethod
    def load_model(self) -> bool:
        """Load the model into memory.

        Returns:
            True if successful, False otherwise
        """
        pass

    @abstractmethod
    def unload_model(self) -> bool:
        """Unload the model from memory.

        Returns:
            True if successful, False otherwise
        """
        pass

    @abstractmethod
    def generate(
        self,
        prompt: str,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None,
        repeat_penalty: Optional[float] = None,
        stop: Optional[list] = None,
        stream: bool = False,
        **kwargs
    ) -> Union[str, Iterator[str]]:
        """Generate text from the model.

        Args:
            prompt: Input prompt
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Nucleus sampling parameter
            top_k: Top-k sampling parameter
            repeat_penalty: Repetition penalty
            stop: Stop sequences
            stream: Whether to stream the response
            **kwargs: Additional model-specific parameters

        Returns:
            Generated text (string) or iterator of text chunks if streaming
        """
        pass

    @abstractmethod
    def get_model_info(self) -> ModelInfo:
        """Get model metadata.

        Returns:
            ModelInfo object with model details
        """
        pass

    def is_loaded(self) -> bool:
        """Check if model is loaded.

        Returns:
            True if model is loaded, False otherwise
        """
        return self.loaded

    def validate_config(self) -> bool:
        """Validate the model configuration.

        Returns:
            True if configuration is valid, False otherwise
        """
        # Basic validation - can be overridden by subclasses
        if not self.model_path:
            return False
        return True

    def get_default_parameters(self) -> Dict[str, Any]:
        """Get default generation parameters.

        Returns:
            Dictionary of default parameters
        """
        return {
            'max_tokens': self.config.get('max_tokens', 512),
            'temperature': self.config.get('temperature', 0.7),
            'top_p': self.config.get('top_p', 0.9),
            'top_k': self.config.get('top_k', 40),
            'repeat_penalty': self.config.get('repeat_penalty', 1.1),
        }

    def __enter__(self):
        """Context manager entry."""
        self.load_model()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.unload_model()
