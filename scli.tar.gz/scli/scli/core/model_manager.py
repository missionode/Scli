"""Model manager for loading and managing model plugins."""

from typing import Dict, Optional, Any
from pathlib import Path

from .config import ConfigManager, ModelConfig
from ..plugins.base import ModelPlugin, ModelInfo
from ..plugins.models.llama_cpp_plugin import LlamaCppPlugin


class ModelManager:
    """Manages model plugins and their lifecycle."""

    # Registry of available plugin types
    PLUGIN_REGISTRY = {
        'llama.cpp': LlamaCppPlugin,
    }

    def __init__(self, config_manager: ConfigManager):
        """Initialize model manager.

        Args:
            config_manager: Configuration manager instance
        """
        self.config_manager = config_manager
        self.current_model: Optional[ModelPlugin] = None
        self.current_model_name: Optional[str] = None

    def load_model(self, model_name: Optional[str] = None) -> bool:
        """Load a model by name.

        Args:
            model_name: Name of model to load. Uses default if None.

        Returns:
            True if successful, False otherwise
        """
        # Unload current model if loaded
        if self.current_model is not None:
            self.unload_model()

        # Get model configuration
        model_config = self.config_manager.get_model_config(model_name)
        if model_config is None:
            if model_name:
                print(f"Error: Model '{model_name}' not found in configuration")
            else:
                print("Error: No default model configured")
            return False

        # Get plugin class for model type
        plugin_class = self.PLUGIN_REGISTRY.get(model_config.type)
        if plugin_class is None:
            print(f"Error: Unknown model type '{model_config.type}'")
            print(f"Available types: {list(self.PLUGIN_REGISTRY.keys())}")
            return False

        # Create plugin configuration
        plugin_config = {
            'context_length': model_config.context_length,
            'temperature': model_config.temperature,
            'top_p': model_config.top_p,
            'top_k': model_config.top_k,
            'repeat_penalty': model_config.repeat_penalty,
            'n_threads': model_config.n_threads,
            'n_gpu_layers': model_config.n_gpu_layers,
            'max_tokens': model_config.max_tokens,
        }

        try:
            # Create plugin instance
            plugin = plugin_class(model_config.path, plugin_config)

            # Validate configuration
            if not plugin.validate_config():
                print("Error: Invalid model configuration")
                return False

            # Load the model
            if plugin.load_model():
                self.current_model = plugin
                self.current_model_name = model_config.name
                return True
            else:
                return False

        except Exception as e:
            print(f"Error loading model: {e}")
            return False

    def unload_model(self) -> bool:
        """Unload the current model.

        Returns:
            True if successful, False otherwise
        """
        if self.current_model is None:
            return True

        try:
            success = self.current_model.unload_model()
            self.current_model = None
            self.current_model_name = None
            return success
        except Exception as e:
            print(f"Error unloading model: {e}")
            return False

    def switch_model(self, model_name: str) -> bool:
        """Switch to a different model.

        Args:
            model_name: Name of model to switch to

        Returns:
            True if successful, False otherwise
        """
        return self.load_model(model_name)

    def generate(
        self,
        prompt: str,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        stream: bool = True,
        **kwargs
    ):
        """Generate text using the current model.

        Args:
            prompt: Input prompt
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            stream: Whether to stream response
            **kwargs: Additional generation parameters

        Returns:
            Generated text or iterator
        """
        if self.current_model is None:
            raise RuntimeError("No model loaded. Call load_model() first.")

        return self.current_model.generate(
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            stream=stream,
            **kwargs
        )

    def get_current_model_info(self) -> Optional[ModelInfo]:
        """Get information about the current model.

        Returns:
            ModelInfo or None if no model loaded
        """
        if self.current_model is None:
            return None
        return self.current_model.get_model_info()

    def is_model_loaded(self) -> bool:
        """Check if a model is currently loaded.

        Returns:
            True if model is loaded, False otherwise
        """
        return self.current_model is not None and self.current_model.is_loaded()

    def list_available_models(self) -> Dict[str, ModelConfig]:
        """List all available models from configuration.

        Returns:
            Dictionary of model configurations
        """
        return self.config_manager.list_models()

    def get_current_model_name(self) -> Optional[str]:
        """Get the name of the currently loaded model.

        Returns:
            Model name or None if no model loaded
        """
        return self.current_model_name

    def register_plugin(self, plugin_type: str, plugin_class):
        """Register a new plugin type.

        Args:
            plugin_type: Type identifier for the plugin
            plugin_class: Plugin class implementing ModelPlugin interface
        """
        if not issubclass(plugin_class, ModelPlugin):
            raise ValueError("Plugin class must inherit from ModelPlugin")

        self.PLUGIN_REGISTRY[plugin_type] = plugin_class

    def get_available_plugin_types(self) -> list:
        """Get list of available plugin types.

        Returns:
            List of plugin type identifiers
        """
        return list(self.PLUGIN_REGISTRY.keys())
