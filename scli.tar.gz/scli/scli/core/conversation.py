"""Conversation manager for handling chat history and context."""

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional, Any
from dataclasses import dataclass, asdict


@dataclass
class Message:
    """Represents a single message in a conversation."""
    role: str  # 'system', 'user', or 'assistant'
    content: str
    timestamp: str = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now().isoformat()

    def to_dict(self) -> Dict[str, str]:
        """Convert to dictionary."""
        return asdict(self)


class Conversation:
    """Represents a conversation with message history."""

    def __init__(self, conversation_id: Optional[str] = None, system_prompt: Optional[str] = None):
        """Initialize conversation.

        Args:
            conversation_id: Unique conversation identifier
            system_prompt: System prompt to set context
        """
        self.conversation_id = conversation_id or self._generate_id()
        self.messages: List[Message] = []
        self.created_at = datetime.now().isoformat()
        self.updated_at = self.created_at

        if system_prompt:
            self.add_message('system', system_prompt)

    @staticmethod
    def _generate_id() -> str:
        """Generate a unique conversation ID."""
        return datetime.now().strftime("%Y%m%d_%H%M%S")

    def add_message(self, role: str, content: str) -> Message:
        """Add a message to the conversation.

        Args:
            role: Message role (system, user, assistant)
            content: Message content

        Returns:
            The created Message object
        """
        message = Message(role=role, content=content)
        self.messages.append(message)
        self.updated_at = datetime.now().isoformat()
        return message

    def get_messages(self, include_system: bool = True) -> List[Message]:
        """Get all messages in the conversation.

        Args:
            include_system: Whether to include system messages

        Returns:
            List of messages
        """
        if include_system:
            return self.messages.copy()
        return [msg for msg in self.messages if msg.role != 'system']

    def get_context(self, max_tokens: Optional[int] = None) -> List[Message]:
        """Get conversation context, optionally limited by tokens.

        Args:
            max_tokens: Maximum approximate tokens to include

        Returns:
            List of messages within token limit
        """
        if max_tokens is None:
            return self.messages.copy()

        # Simple token estimation: ~4 chars per token
        estimated_tokens = 0
        context = []

        # Include system message first if present
        system_messages = [msg for msg in self.messages if msg.role == 'system']
        other_messages = [msg for msg in self.messages if msg.role != 'system']

        for msg in system_messages:
            estimated_tokens += len(msg.content) // 4
            context.append(msg)

        # Add messages from most recent backwards
        for msg in reversed(other_messages):
            msg_tokens = len(msg.content) // 4
            if estimated_tokens + msg_tokens > max_tokens:
                break
            context.insert(len(system_messages), msg)
            estimated_tokens += msg_tokens

        return context

    def format_for_prompt(self) -> str:
        """Format conversation as a prompt string.

        Returns:
            Formatted prompt string
        """
        prompt = ""
        for msg in self.messages:
            if msg.role == 'system':
                prompt += f"System: {msg.content}\n\n"
            elif msg.role == 'user':
                prompt += f"User: {msg.content}\n\n"
            elif msg.role == 'assistant':
                prompt += f"Assistant: {msg.content}\n\n"
        return prompt

    def clear(self):
        """Clear all messages except system messages."""
        self.messages = [msg for msg in self.messages if msg.role == 'system']
        self.updated_at = datetime.now().isoformat()

    def to_dict(self) -> Dict[str, Any]:
        """Convert conversation to dictionary.

        Returns:
            Dictionary representation
        """
        return {
            'conversation_id': self.conversation_id,
            'created_at': self.created_at,
            'updated_at': self.updated_at,
            'messages': [msg.to_dict() for msg in self.messages]
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Conversation':
        """Create conversation from dictionary.

        Args:
            data: Dictionary representation

        Returns:
            Conversation object
        """
        conv = cls(conversation_id=data['conversation_id'])
        conv.created_at = data['created_at']
        conv.updated_at = data['updated_at']
        conv.messages = [
            Message(role=msg['role'], content=msg['content'], timestamp=msg['timestamp'])
            for msg in data['messages']
        ]
        return conv


class ConversationManager:
    """Manages conversation persistence and retrieval."""

    def __init__(self, db_path: str = "./data/history.db"):
        """Initialize conversation manager.

        Args:
            db_path: Path to SQLite database file
        """
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_database()

    def _init_database(self):
        """Initialize the database schema."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS conversations (
                    conversation_id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    data TEXT NOT NULL
                )
            ''')
            conn.commit()

    def save_conversation(self, conversation: Conversation):
        """Save a conversation to the database.

        Args:
            conversation: Conversation to save
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO conversations
                (conversation_id, created_at, updated_at, data)
                VALUES (?, ?, ?, ?)
            ''', (
                conversation.conversation_id,
                conversation.created_at,
                conversation.updated_at,
                json.dumps(conversation.to_dict())
            ))
            conn.commit()

    def load_conversation(self, conversation_id: str) -> Optional[Conversation]:
        """Load a conversation from the database.

        Args:
            conversation_id: ID of conversation to load

        Returns:
            Conversation object or None if not found
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT data FROM conversations
                WHERE conversation_id = ?
            ''', (conversation_id,))

            row = cursor.fetchone()
            if row:
                data = json.loads(row[0])
                return Conversation.from_dict(data)
            return None

    def list_conversations(self, limit: int = 100) -> List[Dict[str, str]]:
        """List recent conversations.

        Args:
            limit: Maximum number of conversations to return

        Returns:
            List of conversation metadata
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT conversation_id, created_at, updated_at
                FROM conversations
                ORDER BY updated_at DESC
                LIMIT ?
            ''', (limit,))

            return [
                {
                    'conversation_id': row[0],
                    'created_at': row[1],
                    'updated_at': row[2]
                }
                for row in cursor.fetchall()
            ]

    def delete_conversation(self, conversation_id: str) -> bool:
        """Delete a conversation from the database.

        Args:
            conversation_id: ID of conversation to delete

        Returns:
            True if deleted, False if not found
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                DELETE FROM conversations
                WHERE conversation_id = ?
            ''', (conversation_id,))
            conn.commit()
            return cursor.rowcount > 0

    def clear_all(self):
        """Delete all conversations from the database."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM conversations')
            conn.commit()
