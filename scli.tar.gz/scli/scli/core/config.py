"""Configuration management for scli."""

import os
import yaml
from pathlib import Path
from typing import Dict, Any, Optional
from dataclasses import dataclass, field


@dataclass
class ModelConfig:
    """Configuration for a single model."""
    name: str
    path: str
    type: str = "llama.cpp"
    context_length: int = 2048
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 40
    repeat_penalty: float = 1.1
    n_threads: Optional[int] = None
    n_gpu_layers: int = 0
    max_tokens: int = 512


@dataclass
class InferenceConfig:
    """Inference settings."""
    max_tokens: int = 2048
    stream: bool = True
    stop_sequences: list = field(default_factory=list)


@dataclass
class UIConfig:
    """UI settings."""
    color_scheme: str = "monokai"
    show_model_name: bool = True
    markdown_rendering: bool = True
    syntax_highlighting: bool = True


@dataclass
class HistoryConfig:
    """History settings."""
    max_conversations: int = 100
    auto_save: bool = True
    save_path: str = "./data/history.db"


class ConfigManager:
    """Manages application configuration."""

    DEFAULT_CONFIG_PATH = Path.home() / ".scli" / "config.yaml"

    def __init__(self, config_path: Optional[Path] = None):
        """Initialize configuration manager.

        Args:
            config_path: Path to configuration file. Uses default if None.
        """
        self.config_path = config_path or self.DEFAULT_CONFIG_PATH
        self.config: Dict[str, Any] = {}
        self.models: Dict[str, ModelConfig] = {}
        self.default_model: Optional[str] = None
        self.inference: InferenceConfig = InferenceConfig()
        self.ui: UIConfig = UIConfig()
        self.history: HistoryConfig = HistoryConfig()

        self._ensure_config_dir()
        self.load()

    def _ensure_config_dir(self):
        """Ensure configuration directory exists."""
        self.config_path.parent.mkdir(parents=True, exist_ok=True)

    def load(self):
        """Load configuration from file."""
        if not self.config_path.exists():
            self._create_default_config()
            return

        try:
            with open(self.config_path, 'r') as f:
                self.config = yaml.safe_load(f) or {}

            self._parse_config()
        except Exception as e:
            print(f"Error loading config: {e}")
            self._create_default_config()

    def _parse_config(self):
        """Parse configuration into structured objects."""
        # Parse models
        models_config = self.config.get('models', {})
        for name, model_data in models_config.items():
            self.models[name] = ModelConfig(
                name=name,
                path=model_data.get('path', ''),
                type=model_data.get('type', 'llama.cpp'),
                context_length=model_data.get('parameters', {}).get('context_length', 2048),
                temperature=model_data.get('parameters', {}).get('temperature', 0.7),
                top_p=model_data.get('parameters', {}).get('top_p', 0.9),
                top_k=model_data.get('parameters', {}).get('top_k', 40),
                repeat_penalty=model_data.get('parameters', {}).get('repeat_penalty', 1.1),
                n_threads=model_data.get('parameters', {}).get('n_threads'),
                n_gpu_layers=model_data.get('parameters', {}).get('n_gpu_layers', 0),
                max_tokens=model_data.get('parameters', {}).get('max_tokens', 512)
            )

        # Default model
        self.default_model = self.config.get('default_model')

        # Inference settings
        inference_data = self.config.get('inference', {})
        self.inference = InferenceConfig(
            max_tokens=inference_data.get('max_tokens', 2048),
            stream=inference_data.get('stream', True),
            stop_sequences=inference_data.get('stop_sequences', [])
        )

        # UI settings
        ui_data = self.config.get('ui', {})
        self.ui = UIConfig(
            color_scheme=ui_data.get('color_scheme', 'monokai'),
            show_model_name=ui_data.get('show_model_name', True),
            markdown_rendering=ui_data.get('markdown_rendering', True),
            syntax_highlighting=ui_data.get('syntax_highlighting', True)
        )

        # History settings
        history_data = self.config.get('history', {})
        self.history = HistoryConfig(
            max_conversations=history_data.get('max_conversations', 100),
            auto_save=history_data.get('auto_save', True),
            save_path=history_data.get('save_path', './data/history.db')
        )

    def _create_default_config(self):
        """Create default configuration file."""
        default_config = {
            'default_model': None,
            'models': {},
            'inference': {
                'max_tokens': 2048,
                'stream': True,
                'stop_sequences': []
            },
            'ui': {
                'color_scheme': 'monokai',
                'show_model_name': True,
                'markdown_rendering': True,
                'syntax_highlighting': True
            },
            'history': {
                'max_conversations': 100,
                'auto_save': True,
                'save_path': './data/history.db'
            }
        }

        self.config = default_config
        self.save()
        self._parse_config()

    def save(self):
        """Save configuration to file."""
        try:
            with open(self.config_path, 'w') as f:
                yaml.dump(self.config, f, default_flow_style=False, indent=2)
        except Exception as e:
            print(f"Error saving config: {e}")

    def add_model(self, name: str, path: str, model_type: str = "llama.cpp",
                  set_default: bool = False, **kwargs):
        """Add a new model to configuration.

        Args:
            name: Model name/identifier
            path: Path to model file
            model_type: Type of model backend
            set_default: Set as default model
            **kwargs: Additional model parameters
        """
        model_config = {
            'path': path,
            'type': model_type,
            'parameters': kwargs
        }

        if 'models' not in self.config:
            self.config['models'] = {}

        self.config['models'][name] = model_config

        if set_default or not self.default_model:
            self.config['default_model'] = name
            self.default_model = name

        self.save()
        self._parse_config()

    def remove_model(self, name: str):
        """Remove a model from configuration.

        Args:
            name: Model name to remove
        """
        if name in self.config.get('models', {}):
            del self.config['models'][name]

            if self.default_model == name:
                # Set new default if available
                if self.config['models']:
                    self.config['default_model'] = list(self.config['models'].keys())[0]
                else:
                    self.config['default_model'] = None
                self.default_model = self.config['default_model']

            self.save()
            self._parse_config()

    def get_model_config(self, name: Optional[str] = None) -> Optional[ModelConfig]:
        """Get configuration for a specific model.

        Args:
            name: Model name. Uses default if None.

        Returns:
            ModelConfig or None if not found
        """
        model_name = name or self.default_model
        return self.models.get(model_name)

    def list_models(self) -> Dict[str, ModelConfig]:
        """Get all configured models.

        Returns:
            Dictionary of model configurations
        """
        return self.models

    def set_default_model(self, name: str):
        """Set the default model.

        Args:
            name: Model name
        """
        if name in self.models:
            self.config['default_model'] = name
            self.default_model = name
            self.save()

    def update_setting(self, section: str, key: str, value: Any):
        """Update a configuration setting.

        Args:
            section: Configuration section (inference, ui, history)
            key: Setting key
            value: New value
        """
        if section not in self.config:
            self.config[section] = {}

        self.config[section][key] = value
        self.save()
        self._parse_config()
