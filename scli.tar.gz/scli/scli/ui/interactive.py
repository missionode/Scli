"""Interactive chat interface."""

import sys
from typing import Optional
from prompt_toolkit import PromptSession
from prompt_toolkit.history import InMemoryHistory
from prompt_toolkit.completion import WordCompleter

from .formatter import Formatter
from ..core.model_manager import ModelManager
from ..core.conversation import Conversation, ConversationManager
from ..core.config import ConfigManager


class InteractiveChatUI:
    """Interactive chat interface with rich formatting."""

    COMMANDS = {
        '/help': 'Show help message',
        '/models': 'List available models',
        '/switch': 'Switch to a different model',
        '/clear': 'Clear current conversation',
        '/save': 'Save current conversation',
        '/history': 'Show conversation history',
        '/exit': 'Exit the application',
        '/quit': 'Exit the application',
    }

    def __init__(
        self,
        model_manager: ModelManager,
        config_manager: ConfigManager,
        conversation_manager: ConversationManager,
        system_prompt: Optional[str] = None
    ):
        """Initialize interactive chat UI.

        Args:
            model_manager: Model manager instance
            config_manager: Configuration manager instance
            conversation_manager: Conversation manager instance
            system_prompt: Optional system prompt
        """
        self.model_manager = model_manager
        self.config_manager = config_manager
        self.conversation_manager = conversation_manager
        self.formatter = Formatter(
            markdown_rendering=config_manager.ui.markdown_rendering,
            syntax_highlighting=config_manager.ui.syntax_highlighting
        )

        # Initialize conversation
        self.conversation = Conversation(system_prompt=system_prompt)

        # Setup prompt session with completion
        command_completer = WordCompleter(
            list(self.COMMANDS.keys()),
            ignore_case=True
        )
        self.session = PromptSession(
            history=InMemoryHistory(),
            completer=command_completer
        )

        self.running = False

    def start(self):
        """Start the interactive chat session."""
        self.running = True
        self.formatter.print_welcome()

        # Show current model info
        if self.model_manager.is_model_loaded():
            model_info = self.model_manager.get_current_model_info()
            if model_info:
                self.formatter.print_info(f"Current model: {model_info.name}")
        else:
            self.formatter.print_warning("No model loaded. Please configure a model first.")
            self.formatter.print_info("Use 'scli models add <path>' to add a model")
            return

        self.formatter.print_divider()

        try:
            while self.running:
                self._chat_loop()
        except KeyboardInterrupt:
            self.formatter.print_system_message("\n\nInterrupted by user")
        except EOFError:
            pass
        finally:
            self._cleanup()

    def _chat_loop(self):
        """Main chat loop."""
        try:
            # Get user input
            user_input = self.session.prompt("\n> ", multiline=False)

            if not user_input.strip():
                return

            # Handle commands
            if user_input.startswith('/'):
                self._handle_command(user_input.strip())
                return

            # Add user message to conversation
            self.conversation.add_message('user', user_input)
            self.formatter.print_user_message(user_input)

            # Generate response
            self._generate_response(user_input)

        except KeyboardInterrupt:
            self.formatter.print_system_message("\n\nGeneration interrupted")
        except Exception as e:
            self.formatter.print_error(f"Error during chat: {e}")

    def _generate_response(self, user_input: str):
        """Generate and display assistant response.

        Args:
            user_input: User's input message
        """
        try:
            # Get conversation context
            context = self.conversation.format_for_prompt()
            prompt = context + "Assistant: "

            # Show generating indicator
            model_name = self.model_manager.get_current_model_name()
            self.formatter.print_system_message("Generating response...", style="dim")

            # Generate with streaming
            if self.config_manager.inference.stream:
                response = self._stream_response(prompt, model_name)
            else:
                response = self._non_stream_response(prompt, model_name)

            # Add assistant response to conversation
            self.conversation.add_message('assistant', response)

            # Auto-save if enabled
            if self.config_manager.history.auto_save:
                self.conversation_manager.save_conversation(self.conversation)

        except Exception as e:
            self.formatter.print_error(f"Failed to generate response: {e}")

    def _stream_response(self, prompt: str, model_name: Optional[str]) -> str:
        """Generate and stream response.

        Args:
            prompt: Full prompt with context
            model_name: Name of the model

        Returns:
            Complete response text
        """
        response_text = ""

        # Print header
        header = f"\n[bold green]Assistant"
        if model_name and self.config_manager.ui.show_model_name:
            header += f" ({model_name})"
        header += ":[/bold green] "
        self.formatter.console.print(header, end="")

        try:
            # Stream generation
            for chunk in self.model_manager.generate(
                prompt=prompt,
                max_tokens=self.config_manager.inference.max_tokens,
                stream=True
            ):
                response_text += chunk
                self.formatter.console.print(chunk, end="")

            self.formatter.console.print("\n")
            return response_text

        except KeyboardInterrupt:
            self.formatter.print_system_message("\n\nGeneration stopped")
            return response_text

    def _non_stream_response(self, prompt: str, model_name: Optional[str]) -> str:
        """Generate response without streaming.

        Args:
            prompt: Full prompt with context
            model_name: Name of the model

        Returns:
            Complete response text
        """
        response_text = self.model_manager.generate(
            prompt=prompt,
            max_tokens=self.config_manager.inference.max_tokens,
            stream=False
        )

        self.formatter.print_assistant_message(response_text, model_name)
        return response_text

    def _handle_command(self, command: str):
        """Handle chat commands.

        Args:
            command: Command string
        """
        parts = command.split(maxsplit=1)
        cmd = parts[0].lower()
        args = parts[1] if len(parts) > 1 else None

        if cmd in ['/exit', '/quit']:
            self.formatter.print_system_message("Goodbye!")
            self.running = False

        elif cmd == '/help':
            self.formatter.print_help()

        elif cmd == '/models':
            self._list_models()

        elif cmd == '/switch':
            if args:
                self._switch_model(args)
            else:
                self.formatter.print_error("Usage: /switch <model_name>")

        elif cmd == '/clear':
            self._clear_conversation()

        elif cmd == '/save':
            self._save_conversation()

        elif cmd == '/history':
            self._show_history()

        else:
            self.formatter.print_error(f"Unknown command: {cmd}")
            self.formatter.print_info("Type /help for available commands")

    def _list_models(self):
        """List all available models."""
        models = self.model_manager.list_available_models()

        if not models:
            self.formatter.print_warning("No models configured")
            return

        current_model = self.model_manager.get_current_model_name()

        rows = []
        for name, config in models.items():
            status = "✓" if name == current_model else " "
            rows.append([status, name, config.type, config.path])

        self.formatter.print_table(
            headers=["Active", "Name", "Type", "Path"],
            rows=rows,
            title="Available Models"
        )

    def _switch_model(self, model_name: str):
        """Switch to a different model.

        Args:
            model_name: Name of model to switch to
        """
        self.formatter.print_info(f"Switching to model: {model_name}...")

        if self.model_manager.switch_model(model_name):
            self.formatter.print_success(f"Switched to model: {model_name}")
        else:
            self.formatter.print_error(f"Failed to switch to model: {model_name}")

    def _clear_conversation(self):
        """Clear the current conversation."""
        self.conversation.clear()
        self.formatter.print_success("Conversation cleared")

    def _save_conversation(self):
        """Save the current conversation."""
        try:
            self.conversation_manager.save_conversation(self.conversation)
            self.formatter.print_success(
                f"Conversation saved with ID: {self.conversation.conversation_id}"
            )
        except Exception as e:
            self.formatter.print_error(f"Failed to save conversation: {e}")

    def _show_history(self):
        """Show conversation history."""
        conversations = self.conversation_manager.list_conversations(limit=10)

        if not conversations:
            self.formatter.print_warning("No saved conversations")
            return

        rows = [
            [conv['conversation_id'], conv['created_at'], conv['updated_at']]
            for conv in conversations
        ]

        self.formatter.print_table(
            headers=["ID", "Created", "Last Updated"],
            rows=rows,
            title="Recent Conversations"
        )

    def _cleanup(self):
        """Cleanup on exit."""
        if self.config_manager.history.auto_save and self.conversation.messages:
            try:
                self.conversation_manager.save_conversation(self.conversation)
            except Exception:
                pass
