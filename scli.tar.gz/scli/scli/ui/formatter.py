"""UI formatting utilities for beautiful terminal output."""

from rich.console import Console
from rich.markdown import Markdown
from rich.syntax import Syntax
from rich.panel import Panel
from rich.text import Text
from rich.table import Table
from typing import Optional


class Formatter:
    """Handles formatted output to the terminal."""

    def __init__(self, markdown_rendering: bool = True, syntax_highlighting: bool = True):
        """Initialize formatter.

        Args:
            markdown_rendering: Enable markdown rendering
            syntax_highlighting: Enable syntax highlighting
        """
        self.console = Console()
        self.markdown_rendering = markdown_rendering
        self.syntax_highlighting = syntax_highlighting

    def print_user_message(self, message: str):
        """Print a user message.

        Args:
            message: User message text
        """
        text = Text()
        text.append("You: ", style="bold cyan")
        text.append(message)
        self.console.print(text)

    def print_assistant_message(self, message: str, model_name: Optional[str] = None):
        """Print an assistant message.

        Args:
            message: Assistant message text
            model_name: Optional model name to display
        """
        # Header
        header = Text()
        header.append("Assistant", style="bold green")
        if model_name:
            header.append(f" ({model_name})", style="dim green")
        header.append(": ", style="bold green")
        self.console.print(header)

        # Message content
        if self.markdown_rendering:
            try:
                md = Markdown(message)
                self.console.print(md)
            except Exception:
                # Fallback to plain text if markdown fails
                self.console.print(message)
        else:
            self.console.print(message)

        self.console.print()  # Empty line

    def print_system_message(self, message: str, style: str = "yellow"):
        """Print a system message.

        Args:
            message: System message text
            style: Rich style for the message
        """
        self.console.print(f"[{style}]{message}[/{style}]")

    def print_error(self, message: str):
        """Print an error message.

        Args:
            message: Error message text
        """
        self.console.print(f"[bold red]Error:[/bold red] {message}")

    def print_warning(self, message: str):
        """Print a warning message.

        Args:
            message: Warning message text
        """
        self.console.print(f"[bold yellow]Warning:[/bold yellow] {message}")

    def print_success(self, message: str):
        """Print a success message.

        Args:
            message: Success message text
        """
        self.console.print(f"[bold green]✓[/bold green] {message}")

    def print_info(self, message: str):
        """Print an info message.

        Args:
            message: Info message text
        """
        self.console.print(f"[bold blue]ℹ[/bold blue] {message}")

    def print_code(self, code: str, language: str = "python"):
        """Print syntax highlighted code.

        Args:
            code: Code to display
            language: Programming language for syntax highlighting
        """
        if self.syntax_highlighting:
            try:
                syntax = Syntax(code, language, theme="monokai", line_numbers=True)
                self.console.print(syntax)
            except Exception:
                # Fallback to plain text
                self.console.print(code)
        else:
            self.console.print(code)

    def print_panel(self, content: str, title: Optional[str] = None, style: str = "blue"):
        """Print content in a panel.

        Args:
            content: Content to display
            title: Optional panel title
            style: Panel border style
        """
        panel = Panel(content, title=title, border_style=style)
        self.console.print(panel)

    def print_table(self, headers: list, rows: list, title: Optional[str] = None):
        """Print a formatted table.

        Args:
            headers: List of column headers
            rows: List of row data (each row is a list)
            title: Optional table title
        """
        table = Table(title=title, show_header=True, header_style="bold magenta")

        for header in headers:
            table.add_column(header)

        for row in rows:
            table.add_row(*[str(cell) for cell in row])

        self.console.print(table)

    def print_divider(self):
        """Print a divider line."""
        self.console.print("─" * self.console.width)

    def print_welcome(self):
        """Print welcome message."""
        welcome_text = """
[bold cyan]╔═══════════════════════════════════════════════════════╗
║          Welcome to SCLI - Offline CLI Assistant      ║
║                  Powered by Open Source LLMs          ║
╚═══════════════════════════════════════════════════════╝[/bold cyan]

Type your message and press Enter to chat.
Commands:
  /help    - Show help
  /models  - List available models
  /switch  - Switch model
  /clear   - Clear conversation
  /save    - Save conversation
  /exit    - Exit the application
        """
        self.console.print(welcome_text)

    def print_help(self):
        """Print help information."""
        help_text = """
[bold cyan]Available Commands:[/bold cyan]

  [bold green]/help[/bold green]              Show this help message
  [bold green]/models[/bold green]            List all available models
  [bold green]/switch <model>[/bold green]    Switch to a different model
  [bold green]/clear[/bold green]             Clear the current conversation
  [bold green]/save[/bold green]              Save the current conversation
  [bold green]/history[/bold green]           Show conversation history
  [bold green]/exit[/bold green] or [bold green]/quit[/bold green]   Exit the application

[bold cyan]Tips:[/bold cyan]
  - Press Ctrl+C to cancel generation
  - Use markdown formatting in your messages
  - Code blocks are automatically syntax highlighted
        """
        self.console.print(help_text)

    def stream_text(self, text: str, end: str = ""):
        """Stream text output without newline.

        Args:
            text: Text to print
            end: End character (default: no newline)
        """
        self.console.print(text, end=end)

    def clear_screen(self):
        """Clear the terminal screen."""
        self.console.clear()

    def print_model_info(self, model_info: dict):
        """Print formatted model information.

        Args:
            model_info: Dictionary with model information
        """
        self.print_panel(
            f"""[bold]Name:[/bold] {model_info.get('name', 'N/A')}
[bold]Type:[/bold] {model_info.get('type', 'N/A')}
[bold]Path:[/bold] {model_info.get('path', 'N/A')}
[bold]Context Length:[/bold] {model_info.get('context_length', 'N/A')}
[bold]Status:[/bold] {'Loaded' if model_info.get('loaded', False) else 'Not Loaded'}""",
            title="Model Information",
            style="green" if model_info.get('loaded', False) else "yellow"
        )
